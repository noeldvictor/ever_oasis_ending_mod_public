@echo off
setlocal EnableExtensions DisableDelayedExpansion
title Ever Oasis Triumphant Ending v221 Preview
set "PATCH_DIR=%~dp0"
set "EXPECTED_SOURCE=A8EC061AD09A29AFD552C9DEDC836E7A8B355ED3A0C69ACC47A78BED63A78687"
set "EXPECTED_OUTPUT=3973C0E1451783F5BFDE712A61F0CF3CC740EE7F4061BBD43D31FAF2D3D7AEFA"
set "RESULT=1"
if "%~1"=="" goto usage
set "EO_SOURCE=%~f1"
if not exist "%EO_SOURCE%" goto missing
echo Checking the clean game image...
set "SOURCE_HASH="
for /f "skip=1 delims=" %%H in ('certutil.exe -hashfile "%EO_SOURCE%" SHA256') do if not defined SOURCE_HASH set "SOURCE_HASH=%%H"
set "SOURCE_HASH=%SOURCE_HASH: =%"
if /I not "%SOURCE_HASH%"=="%EXPECTED_SOURCE%" goto wrongsource
for %%I in ("%EO_SOURCE%") do set "EO_OUTPUT=%%~dpIEver Oasis - Triumphant Ending v221-DIAGNOSTIC-public-preview.3ds"
if exist "%EO_OUTPUT%" goto outputexists
echo Applying the xdelta patch. This can take a minute...
"%PATCH_DIR%xdelta3.exe" -d -s "%EO_SOURCE%" "%PATCH_DIR%ever-oasis-triumphant-ending-v221-DIAGNOSTIC-public-preview.xdelta" "%EO_OUTPUT%"
if errorlevel 1 goto patchfailed
echo Verifying the patched game image...
set "OUTPUT_HASH="
for /f "skip=1 delims=" %%H in ('certutil.exe -hashfile "%EO_OUTPUT%" SHA256') do if not defined OUTPUT_HASH set "OUTPUT_HASH=%%H"
set "OUTPUT_HASH=%OUTPUT_HASH: =%"
if /I not "%OUTPUT_HASH%"=="%EXPECTED_OUTPUT%" goto outputfailed
echo.
echo Success: %EO_OUTPUT%
echo Diagnostic preview. Original-hardware confirmation is pending.
set "RESULT=0"
goto done
:usage
echo Drag your clean decrypted English US v0 Ever Oasis .3ds or .cci file onto apply_patch.bat.
goto done
:missing
echo ERROR: The selected source file does not exist.
goto done
:wrongsource
echo ERROR: This is not the supported clean decrypted English US v0 image.
echo Expected SHA-256: %EXPECTED_SOURCE%
echo Actual SHA-256:   %SOURCE_HASH%
goto done
:outputexists
echo ERROR: The output already exists: %EO_OUTPUT%
echo Rename it before trying again. No existing output was changed.
goto done
:patchfailed
if exist "%EO_OUTPUT%" del /q "%EO_OUTPUT%"
echo ERROR: xdelta could not apply the patch.
goto done
:outputfailed
if exist "%EO_OUTPUT%" del /q "%EO_OUTPUT%"
echo ERROR: Output verification failed. The incomplete output was removed.
:done
if not defined EO_NOPAUSE pause
exit /b %RESULT%
