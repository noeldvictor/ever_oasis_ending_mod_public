Ever Oasis: Triumphant Ending v221 - diagnostic preview

Use a legally owned clean decrypted English US v0 .3ds or .cci image.
Source SHA-256: A8EC061AD09A29AFD552C9DEDC836E7A8B355ED3A0C69ACC47A78BED63A78687
Source size: 860192768 bytes

Extract the entire ZIP. Drag the matching image onto apply_patch.bat.
The launcher checks the source, applies xdelta and verifies the output.
The original image is read-only. No Python or extracted RomFS is needed.

Output: Ever Oasis - Triumphant Ending v221-DIAGNOSTIC-public-preview.3ds
Output SHA-256: 3973C0E1451783F5BFDE712A61F0CF3CC740EE7F4061BBD43D31FAF2D3D7AEFA

This ending preview features a warm homecoming and sunny blue sky.
This diagnostic is not a hardware-qualified release. Authentic final-boss
verification and original-hardware confirmation remain pending.

Only a delta, original launcher/metadata and xdelta3/GPL source are included.
Do not distribute the patched game image. Back up your save before testing.
